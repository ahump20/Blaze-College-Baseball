// src/hooks/useCollegeBaseballData.js
// React hooks for connecting to Cloudflare Workers API

import { useState, useEffect, useCallback, useRef } from 'react';

const API_BASE = process.env.REACT_APP_API_URL || 'https://api.blazesportsintel.com';
const WS_BASE = process.env.REACT_APP_WS_URL || 'wss://live.blazesportsintel.com';

/**
 * Hook for fetching live games with automatic refresh
 */
export function useLiveGames(refreshInterval = 30000) {
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchGames = useCallback(async () => {
    try {
      const response = await fetch(`${API_BASE}/api/games/live`);
      if (!response.ok) throw new Error('Failed to fetch games');
      
      const data = await response.json();
      setGames(data);
      setError(null);
    } catch (err) {
      setError(err.message);
      console.error('Error fetching games:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchGames();
    
    // Auto-refresh every 30 seconds
    const interval = setInterval(fetchGames, refreshInterval);
    
    return () => clearInterval(interval);
  }, [fetchGames, refreshInterval]);

  return { games, loading, error, refresh: fetchGames };
}

/**
 * Hook for fetching box score data for a specific game
 */
export function useBoxScore(gameId) {
  const [boxScore, setBoxScore] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!gameId) {
      setBoxScore(null);
      setLoading(false);
      return;
    }

    const fetchBoxScore = async () => {
      try {
        setLoading(true);
        const response = await fetch(`${API_BASE}/api/games/${gameId}/boxscore`);
        if (!response.ok) throw new Error('Failed to fetch box score');
        
        const data = await response.json();
        setBoxScore(data);
        setError(null);
      } catch (err) {
        setError(err.message);
        console.error('Error fetching box score:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchBoxScore();
  }, [gameId]);

  return { boxScore, loading, error };
}

/**
 * Hook for conference standings
 */
export function useStandings(conference) {
  const [standings, setStandings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!conference) return;

    const fetchStandings = async () => {
      try {
        setLoading(true);
        const response = await fetch(`${API_BASE}/api/standings/${conference}`);
        if (!response.ok) throw new Error('Failed to fetch standings');
        
        const data = await response.json();
        setStandings(data);
        setError(null);
      } catch (err) {
        setError(err.message);
        console.error('Error fetching standings:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchStandings();
  }, [conference]);

  return { standings, loading, error };
}

/**
 * Hook for live game updates via WebSocket (Durable Objects)
 */
export function useLiveGameUpdates(gameId) {
  const [gameState, setGameState] = useState(null);
  const [connected, setConnected] = useState(false);
  const wsRef = useRef(null);

  useEffect(() => {
    if (!gameId) return;

    // Connect to WebSocket
    const ws = new WebSocket(`${WS_BASE}/game/${gameId}`);
    wsRef.current = ws;

    ws.onopen = () => {
      console.log(`Connected to game ${gameId}`);
      setConnected(true);
    };

    ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        
        if (message.type === 'init') {
          // Initial game state
          setGameState(message.data);
        } else if (message.type === 'update') {
          // Incremental update
          setGameState(prev => ({
            ...prev,
            ...message.data
          }));
        }
      } catch (err) {
        console.error('Error parsing WebSocket message:', err);
      }
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
      setConnected(false);
    };

    ws.onclose = () => {
      console.log(`Disconnected from game ${gameId}`);
      setConnected(false);
    };

    // Cleanup on unmount
    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.close();
      }
    };
  }, [gameId]);

  return { gameState, connected };
}

/**
 * Hook for offline support using Service Worker cache
 */
export function useOfflineSupport() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [cachedGames, setCachedGames] = useState([]);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const cacheGames = useCallback(async (games) => {
    if ('caches' in window) {
      const cache = await caches.open('blaze-sports-v1');
      const response = new Response(JSON.stringify(games));
      await cache.put('/api/games/live', response);
      setCachedGames(games);
    }
  }, []);

  const loadCachedGames = useCallback(async () => {
    if ('caches' in window) {
      const cache = await caches.open('blaze-sports-v1');
      const response = await cache.match('/api/games/live');
      if (response) {
        const games = await response.json();
        setCachedGames(games);
        return games;
      }
    }
    return [];
  }, []);

  return { isOnline, cachedGames, cacheGames, loadCachedGames };
}

/**
 * Hook for search functionality
 */
export function useTeamSearch(query) {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!query || query.length < 2) {
      setResults([]);
      return;
    }

    const searchTeams = async () => {
      setLoading(true);
      try {
        const response = await fetch(
          `${API_BASE}/api/teams/search?q=${encodeURIComponent(query)}`
        );
        if (!response.ok) throw new Error('Search failed');
        
        const data = await response.json();
        setResults(data);
      } catch (err) {
        console.error('Search error:', err);
      } finally {
        setLoading(false);
      }
    };

    // Debounce search
    const timeoutId = setTimeout(searchTeams, 300);
    return () => clearTimeout(timeoutId);
  }, [query]);

  return { results, loading };
}

/**
 * Hook for push notifications
 */
export function usePushNotifications() {
  const [permission, setPermission] = useState(Notification.permission);
  const [subscription, setSubscription] = useState(null);

  const requestPermission = useCallback(async () => {
    if (!('Notification' in window)) {
      console.log('Notifications not supported');
      return false;
    }

    const result = await Notification.requestPermission();
    setPermission(result);
    return result === 'granted';
  }, []);

  const subscribe = useCallback(async (gameId) => {
    if (permission !== 'granted') {
      const granted = await requestPermission();
      if (!granted) return;
    }

    try {
      // Register service worker if not already registered
      const registration = await navigator.serviceWorker.ready;
      
      // Subscribe to push notifications
      const sub = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: process.env.REACT_APP_VAPID_PUBLIC_KEY
      });

      // Send subscription to server
      await fetch(`${API_BASE}/api/notifications/subscribe`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subscription: sub,
          gameId
        })
      });

      setSubscription(sub);
    } catch (err) {
      console.error('Subscription error:', err);
    }
  }, [permission, requestPermission]);

  return { permission, subscribe, subscription };
}

/**
 * Combined hook that provides all data for the dashboard
 */
export function useCollegeBaseballDashboard(selectedSport = 'college-baseball') {
  const { games, loading: gamesLoading, error: gamesError, refresh } = useLiveGames();
  const { standings, loading: standingsLoading } = useStandings('SEC');
  const { isOnline, cacheGames, loadCachedGames } = useOfflineSupport();

  // Cache games when online
  useEffect(() => {
    if (isOnline && games.length > 0) {
      cacheGames(games);
    }
  }, [isOnline, games, cacheGames]);

  // Load cached games when offline
  useEffect(() => {
    if (!isOnline) {
      loadCachedGames();
    }
  }, [isOnline, loadCachedGames]);

  return {
    games,
    standings,
    loading: gamesLoading || standingsLoading,
    error: gamesError,
    isOnline,
    refresh
  };
}

// Export all hooks
export default {
  useLiveGames,
  useBoxScore,
  useStandings,
  useLiveGameUpdates,
  useOfflineSupport,
  useTeamSearch,
  usePushNotifications,
  useCollegeBaseballDashboard
};
