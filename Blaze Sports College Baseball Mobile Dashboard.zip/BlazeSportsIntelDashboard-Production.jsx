// src/components/BlazeSportsIntelDashboard-Production.jsx
// Production version with real Cloudflare Workers API integration

import React, { useState, useEffect } from 'react';
import { ChevronDown, ChevronRight, Search, Bell, Menu, Star, TrendingUp, Calendar, Users, X, Filter, Wifi, WifiOff } from 'lucide-react';
import { 
  useLiveGames, 
  useBoxScore, 
  useStandings, 
  useLiveGameUpdates,
  useOfflineSupport,
  usePushNotifications 
} from '../hooks/useCollegeBaseballData';

const BlazeSportsIntelDashboard = () => {
  const [selectedSport, setSelectedSport] = useState('college-baseball');
  const [selectedGame, setSelectedGame] = useState(null);
  const [activeTab, setActiveTab] = useState('scores');
  const [showMenu, setShowMenu] = useState(false);

  // Fetch live games data
  const { games, loading: gamesLoading, error: gamesError, refresh } = useLiveGames(30000); // refresh every 30s
  
  // Fetch standings
  const { standings, loading: standingsLoading } = useStandings('SEC');
  
  // Box score for selected game
  const { boxScore, loading: boxScoreLoading } = useBoxScore(selectedGame?.id);
  
  // Live updates via WebSocket for selected game
  const { gameState, connected } = useLiveGameUpdates(selectedGame?.id);
  
  // Offline support
  const { isOnline } = useOfflineSupport();
  
  // Push notifications
  const { permission, subscribe } = usePushNotifications();

  // Update selected game with live data
  useEffect(() => {
    if (gameState && selectedGame) {
      setSelectedGame(prev => ({
        ...prev,
        ...gameState
      }));
    }
  }, [gameState, selectedGame]);

  const sports = [
    { id: 'college-baseball', name: 'College Baseball', icon: '⚾', count: games.filter(g => g.sport === 'college-baseball').length },
    { id: 'track-field', name: 'Track & Field', icon: '🏃', count: 12 },
    { id: 'ncaa-soccer', name: 'NCAA Soccer', icon: '⚽', count: 8 },
    { id: 'softball', name: 'Softball', icon: '🥎', count: 23 },
    { id: 'mlb', name: 'MLB', icon: '⚾', count: 15 },
    { id: 'nfl', name: 'NFL', icon: '🏈', count: 10 },
  ];

  const GameCard = ({ game }) => {
    const isLive = !game.status.includes('Final');
    const isSelected = selectedGame?.id === game.id;

    const handleGameClick = async () => {
      setSelectedGame(game);
      
      // Subscribe to notifications for this game
      if (isLive && permission !== 'granted') {
        await subscribe(game.id);
      }
    };

    return (
      <div 
        onClick={handleGameClick}
        className={`bg-gray-800 rounded-lg p-4 mb-3 border-2 transition-all cursor-pointer ${
          isSelected ? 'border-orange-500' : 'border-gray-700'
        } active:scale-98`}
      >
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            {isLive && (
              <div className="flex items-center">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse mr-2"></div>
                <span className="text-red-500 text-xs font-bold">LIVE</span>
              </div>
            )}
            <span className="text-gray-400 text-xs">{game.conference}</span>
          </div>
          <span className="text-gray-400 text-xs">{game.venue}</span>
        </div>

        {/* Away Team */}
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-3 flex-1">
            {game.away_rank && (
              <span className="text-yellow-500 font-bold text-sm">#{game.away_rank}</span>
            )}
            <div>
              <div className="font-bold text-white">{game.away_team_name}</div>
              <div className="text-xs text-gray-400">
                {game.away_wins}-{game.away_losses}, {game.away_conf_wins}-{game.away_conf_losses} {game.conference}
              </div>
            </div>
          </div>
          <div className="text-2xl font-bold text-white">{game.away_score}</div>
        </div>

        {/* Home Team */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-3 flex-1">
            {game.home_rank && (
              <span className="text-yellow-500 font-bold text-sm">#{game.home_rank}</span>
            )}
            <div>
              <div className="font-bold text-white">{game.home_team_name}</div>
              <div className="text-xs text-gray-400">
                {game.home_wins}-{game.home_losses}, {game.home_conf_wins}-{game.home_conf_losses} {game.conference}
              </div>
            </div>
          </div>
          <div className="text-2xl font-bold text-white">{game.home_score}</div>
        </div>

        {/* Game Status */}
        <div className="flex items-center justify-between pt-2 border-t border-gray-700">
          <span className="text-orange-500 font-semibold text-sm">{game.status}</span>
          {game.situation && isLive && (
            <span className="text-gray-400 text-xs">{game.situation}</span>
          )}
          {game.attendance && (
            <span className="text-gray-400 text-xs">Att: {game.attendance}</span>
          )}
        </div>

        <div className="mt-2 text-center text-orange-400 text-xs">
          Tap for full box score →
        </div>
      </div>
    );
  };

  const BoxScore = () => {
    if (!selectedGame || !boxScore) return null;

    const awayBatting = boxScore.batting.filter(p => p.team_abbr === selectedGame.away_team_abbr);
    const homeBatting = boxScore.batting.filter(p => p.team_abbr === selectedGame.home_team_abbr);
    const awayPitching = boxScore.pitching.filter(p => p.team_abbr === selectedGame.away_team_abbr);
    const homePitching = boxScore.pitching.filter(p => p.team_abbr === selectedGame.home_team_abbr);

    return (
      <div className="fixed inset-0 bg-black bg-opacity-95 z-50 overflow-y-auto">
        <div className="min-h-screen p-4">
          {/* Header */}
          <div className="flex items-center justify-between mb-4 sticky top-0 bg-black py-2 z-10">
            <div className="flex items-center space-x-2">
              <h2 className="text-xl font-bold text-white">Box Score</h2>
              {connected && (
                <div className="flex items-center text-green-500 text-xs">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-1 animate-pulse"></div>
                  LIVE
                </div>
              )}
            </div>
            <button 
              onClick={() => setSelectedGame(null)}
              className="text-white p-2"
            >
              <X size={24} />
            </button>
          </div>

          {boxScoreLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mx-auto"></div>
              <p className="text-gray-400 mt-4">Loading box score...</p>
            </div>
          ) : (
            <>
              {/* Game Summary */}
              <div className="bg-gray-800 rounded-lg p-4 mb-4">
                <div className="text-center mb-2">
                  <span className="text-gray-400 text-sm">{selectedGame.conference}</span>
                  <span className="text-gray-400 text-sm mx-2">•</span>
                  <span className="text-gray-400 text-sm">{selectedGame.venue}</span>
                </div>
                <div className="flex justify-around items-center">
                  <div className="text-center">
                    <div className="font-bold text-lg text-white">{selectedGame.away_team_name}</div>
                    <div className="text-3xl font-bold text-white">{selectedGame.away_score}</div>
                  </div>
                  <div className="text-gray-500 text-2xl">-</div>
                  <div className="text-center">
                    <div className="font-bold text-lg text-white">{selectedGame.home_team_name}</div>
                    <div className="text-3xl font-bold text-white">{selectedGame.home_score}</div>
                  </div>
                </div>
                <div className="text-center mt-2">
                  <span className="text-orange-500 font-semibold">{selectedGame.status}</span>
                </div>
              </div>

              {/* Batting Stats Tables */}
              <BattingTable team={selectedGame.away_team_name} players={awayBatting} />
              <BattingTable team={selectedGame.home_team_name} players={homeBatting} />

              {/* Pitching Stats Tables */}
              <PitchingTable team={selectedGame.away_team_name} players={awayPitching} />
              <PitchingTable team={selectedGame.home_team_name} players={homePitching} />
            </>
          )}
        </div>
      </div>
    );
  };

  const BattingTable = ({ team, players }) => (
    <div className="bg-gray-800 rounded-lg p-4 mb-4">
      <h3 className="font-bold text-white mb-3">{team} Batting</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="text-gray-400 border-b border-gray-700">
              <th className="text-left py-2 pr-2">Player</th>
              <th className="text-center px-1">AB</th>
              <th className="text-center px-1">R</th>
              <th className="text-center px-1">H</th>
              <th className="text-center px-1">RBI</th>
              <th className="text-center px-1">BB</th>
              <th className="text-center px-1">SO</th>
              <th className="text-center px-1">AVG</th>
            </tr>
          </thead>
          <tbody className="text-white">
            {players.map((player, i) => (
              <tr key={i} className="border-b border-gray-700">
                <td className="py-2 pr-2">
                  <div className="font-semibold">{player.player_name}</div>
                  <div className="text-gray-400">{player.position}</div>
                </td>
                <td className="text-center px-1">{player.at_bats}</td>
                <td className="text-center px-1">{player.runs}</td>
                <td className="text-center px-1">{player.hits}</td>
                <td className="text-center px-1">{player.rbis}</td>
                <td className="text-center px-1">{player.walks}</td>
                <td className="text-center px-1">{player.strikeouts}</td>
                <td className="text-center px-1">{player.batting_avg}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const PitchingTable = ({ team, players }) => (
    <div className="bg-gray-800 rounded-lg p-4 mb-4">
      <h3 className="font-bold text-white mb-3">{team} Pitching</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="text-gray-400 border-b border-gray-700">
              <th className="text-left py-2 pr-2">Player</th>
              <th className="text-center px-1">IP</th>
              <th className="text-center px-1">H</th>
              <th className="text-center px-1">R</th>
              <th className="text-center px-1">ER</th>
              <th className="text-center px-1">BB</th>
              <th className="text-center px-1">SO</th>
              <th className="text-center px-1">ERA</th>
              <th className="text-center px-1">P</th>
            </tr>
          </thead>
          <tbody className="text-white">
            {players.map((player, i) => (
              <tr key={i} className="border-b border-gray-700">
                <td className="py-2 pr-2 font-semibold">{player.player_name}</td>
                <td className="text-center px-1">{player.innings_pitched}</td>
                <td className="text-center px-1">{player.hits_allowed}</td>
                <td className="text-center px-1">{player.runs_allowed}</td>
                <td className="text-center px-1">{player.earned_runs}</td>
                <td className="text-center px-1">{player.walks_allowed}</td>
                <td className="text-center px-1">{player.strikeouts_pitcher}</td>
                <td className="text-center px-1">{player.era}</td>
                <td className="text-center px-1">{player.pitches}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  if (gamesError) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <div className="text-red-500 text-xl mb-2">Error loading data</div>
          <p className="text-gray-400 mb-4">{gamesError}</p>
          <button 
            onClick={refresh}
            className="px-4 py-2 bg-orange-500 rounded-lg"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-600 to-orange-500 p-4 sticky top-0 z-40">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <button onClick={() => setShowMenu(!showMenu)}>
              <Menu size={24} />
            </button>
            <div>
              <h1 className="text-xl font-bold">Blaze Sports Intel</h1>
              <p className="text-xs text-orange-50">Every team. Every conference. Every game.</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {!isOnline && <WifiOff size={20} className="text-yellow-500" />}
            <button className="p-2"><Search size={20} /></button>
            <button className="p-2 relative">
              <Bell size={20} />
              {permission === 'default' && (
                <div className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></div>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Sport Selector */}
      <div className="bg-gray-900 p-3 overflow-x-auto scrollbar-hide sticky top-16 z-30 border-b border-gray-800">
        <div className="flex space-x-2 min-w-max">
          {sports.map(sport => (
            <button
              key={sport.id}
              onClick={() => setSelectedSport(sport.id)}
              className={`px-4 py-2 rounded-full text-sm font-semibold transition-all whitespace-nowrap ${
                selectedSport === sport.id
                  ? 'bg-orange-500 text-white'
                  : 'bg-gray-800 text-gray-300'
              }`}
            >
              <span className="mr-2">{sport.icon}</span>
              {sport.name}
              <span className="ml-2 text-xs opacity-75">({sport.count})</span>
            </button>
          ))}
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-gray-900 p-3 flex space-x-4 border-b border-gray-800 sticky top-32 z-30">
        {['scores', 'standings', 'schedule'].map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-sm font-semibold transition-all ${
              activeTab === tab
                ? 'text-orange-500 border-b-2 border-orange-500'
                : 'text-gray-400'
            }`}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="p-4">
        {/* Hero Message */}
        <div className="bg-gradient-to-r from-orange-600 to-orange-500 rounded-lg p-6 mb-6">
          <h2 className="text-2xl font-bold mb-2">Full College Baseball Coverage</h2>
          <p className="text-orange-50 mb-3">
            Complete box scores, player stats, and standings for all 300+ D1 teams. 
            Not just SEC highlight clips.
          </p>
          <div className="mt-3 flex flex-wrap gap-3 text-xs text-orange-50">
            <div>✓ All 300+ D1 teams</div>
            <div>✓ Every conference</div>
            <div>✓ Real-time updates</div>
            <div>✓ Complete stats</div>
          </div>
        </div>

        {activeTab === 'scores' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold">
                {gamesLoading ? 'Loading...' : `Live & Recent Games (${games.length})`}
              </h3>
              <button 
                onClick={refresh}
                className="text-orange-500 text-sm flex items-center"
              >
                <TrendingUp size={16} className="mr-1" />
                Refresh
              </button>
            </div>
            
            {gamesLoading && games.length === 0 ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mx-auto"></div>
              </div>
            ) : games.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                No games available
              </div>
            ) : (
              games.map(game => <GameCard key={game.id} game={game} />)
            )}
          </div>
        )}

        {activeTab === 'standings' && (
          <div>
            <div className="bg-gray-800 rounded-lg p-4 mb-4">
              <h3 className="text-lg font-bold mb-4">SEC Standings</h3>
              {standingsLoading ? (
                <div className="text-center py-4">Loading...</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="text-gray-400 border-b border-gray-700">
                        <th className="text-left py-2">#</th>
                        <th className="text-left py-2">Team</th>
                        <th className="text-center px-2">Conf</th>
                        <th className="text-center px-2">Overall</th>
                        <th className="text-center px-2">GB</th>
                        <th className="text-center px-2">Strk</th>
                      </tr>
                    </thead>
                    <tbody className="text-white">
                      {standings.map((team, i) => (
                        <tr key={i} className="border-b border-gray-700">
                          <td className="py-3">{team.rank}</td>
                          <td className="py-3 font-semibold">{team.team}</td>
                          <td className="text-center">{team.conf}</td>
                          <td className="text-center">{team.overall}</td>
                          <td className="text-center">{team.gb}</td>
                          <td className="text-center">
                            <span className={team.streak.startsWith('W') ? 'text-green-500' : 'text-red-500'}>
                              {team.streak}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Box Score Modal */}
      {selectedGame && <BoxScore />}

      <style jsx>{`
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
};

export default BlazeSportsIntelDashboard;
