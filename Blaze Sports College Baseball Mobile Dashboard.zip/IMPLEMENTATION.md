# Blaze Sports Intel Dashboard - Implementation Guide

## What's Built

Mobile-first React component with:
- **Complete box scores** (batting + pitching stats) - something ESPN refuses to provide for college baseball
- Live game tracking with situation updates
- Conference standings
- Game schedule with reminders
- All 300+ D1 teams coverage (not just SEC clips)
- Swipeable navigation optimized for mobile
- Offline-first design ready

## Cloudflare Stack Integration

### 1. Data Layer (Cloudflare D1)

Create tables for college baseball data:

```sql
-- Teams table
CREATE TABLE teams (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  abbr TEXT NOT NULL,
  conference TEXT NOT NULL,
  division TEXT,
  logo_url TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Games table
CREATE TABLE games (
  id INTEGER PRIMARY KEY,
  home_team_id INTEGER NOT NULL,
  away_team_id INTEGER NOT NULL,
  home_score INTEGER DEFAULT 0,
  away_score INTEGER DEFAULT 0,
  status TEXT DEFAULT 'scheduled',
  inning TEXT,
  situation TEXT,
  venue TEXT,
  attendance INTEGER,
  game_date DATETIME NOT NULL,
  conference TEXT,
  FOREIGN KEY (home_team_id) REFERENCES teams(id),
  FOREIGN KEY (away_team_id) REFERENCES teams(id)
);

-- Player stats table
CREATE TABLE player_stats (
  id INTEGER PRIMARY KEY,
  game_id INTEGER NOT NULL,
  team_id INTEGER NOT NULL,
  player_name TEXT NOT NULL,
  position TEXT,
  -- Batting
  at_bats INTEGER DEFAULT 0,
  runs INTEGER DEFAULT 0,
  hits INTEGER DEFAULT 0,
  rbis INTEGER DEFAULT 0,
  walks INTEGER DEFAULT 0,
  strikeouts INTEGER DEFAULT 0,
  batting_avg REAL,
  -- Pitching
  innings_pitched REAL,
  hits_allowed INTEGER,
  runs_allowed INTEGER,
  earned_runs INTEGER,
  walks_allowed INTEGER,
  strikeouts_pitcher INTEGER,
  era REAL,
  pitches INTEGER,
  FOREIGN KEY (game_id) REFERENCES games(id),
  FOREIGN KEY (team_id) REFERENCES teams(id)
);

-- Standings table
CREATE TABLE standings (
  id INTEGER PRIMARY KEY,
  team_id INTEGER NOT NULL,
  conference TEXT NOT NULL,
  conf_wins INTEGER DEFAULT 0,
  conf_losses INTEGER DEFAULT 0,
  overall_wins INTEGER DEFAULT 0,
  overall_losses INTEGER DEFAULT 0,
  streak TEXT,
  rank INTEGER,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (team_id) REFERENCES teams(id)
);
```

### 2. Cloudflare Workers API Endpoints

Create these Worker endpoints:

**`/api/games/live`**
```javascript
export default {
  async fetch(request, env) {
    const db = env.DB; // D1 database binding
    
    const games = await db.prepare(`
      SELECT 
        g.*,
        ht.name as home_team_name, ht.abbr as home_abbr, ht.conference,
        at.name as away_team_name, at.abbr as away_abbr
      FROM games g
      JOIN teams ht ON g.home_team_id = ht.id
      JOIN teams at ON g.away_team_id = at.id
      WHERE g.status IN ('live', 'final')
        AND DATE(g.game_date) = DATE('now')
      ORDER BY g.game_date DESC
    `).all();
    
    return Response.json(games.results);
  }
}
```

**`/api/games/:id/boxscore`**
```javascript
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const gameId = url.pathname.split('/')[3];
    const db = env.DB;
    
    // Get game info
    const game = await db.prepare(`
      SELECT * FROM games WHERE id = ?
    `).bind(gameId).first();
    
    // Get all player stats for this game
    const stats = await db.prepare(`
      SELECT * FROM player_stats 
      WHERE game_id = ?
      ORDER BY team_id, at_bats DESC
    `).bind(gameId).all();
    
    return Response.json({
      game,
      stats: stats.results
    });
  }
}
```

**`/api/standings/:conference`**
```javascript
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const conference = url.pathname.split('/')[3];
    const db = env.DB;
    
    const standings = await db.prepare(`
      SELECT 
        s.*,
        t.name as team_name,
        t.abbr
      FROM standings s
      JOIN teams t ON s.team_id = t.id
      WHERE s.conference = ?
      ORDER BY 
        (s.conf_wins * 1.0 / NULLIF(s.conf_wins + s.conf_losses, 0)) DESC,
        s.conf_wins DESC
    `).bind(conference).all();
    
    return Response.json(standings.results);
  }
}
```

### 3. Data Sources to Scrape

College baseball data is scattered. Here's where to get it:

#### Primary Sources:
1. **NCAA Stats** - stats.ncaa.org
   - Box scores
   - Team schedules
   - Player stats
   
2. **Conference Websites**
   - SEC: secsports.com/sport/baseball
   - ACC: theacc.com/sports/baseball
   - Pac-12: pac-12.com/sport/baseball
   - Big 12: big12sports.com/sports/baseball
   - Each has their own API/feed

3. **D1Baseball.com** 
   - Rankings
   - Schedules
   - RPI data

4. **Boyd's World** (boydsworld.com)
   - Advanced metrics
   - Historical data

#### Scraper Worker Example:

```javascript
// Worker that runs on schedule (cron trigger)
export default {
  async scheduled(event, env, ctx) {
    // Scrape NCAA games
    const ncaaGames = await fetch('https://stats.ncaa.org/...');
    const games = await ncaaGames.json();
    
    // Update D1 database
    for (const game of games) {
      await env.DB.prepare(`
        INSERT OR REPLACE INTO games 
        (id, home_team_id, away_team_id, home_score, away_score, status, inning)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).bind(
        game.id,
        game.homeTeamId,
        game.awayTeamId,
        game.homeScore,
        game.awayScore,
        game.status,
        game.inning
      ).run();
    }
  }
}
```

### 4. Caching Strategy (Cloudflare KV)

Cache frequently accessed data:

```javascript
// In your API worker
const cached = await env.CACHE.get(`games:live:${date}`);
if (cached) {
  return Response.json(JSON.parse(cached));
}

const fresh = await fetchFromD1();
await env.CACHE.put(
  `games:live:${date}`, 
  JSON.stringify(fresh),
  { expirationTtl: 60 } // 60 second cache
);

return Response.json(fresh);
```

### 5. Real-time Updates

Use Cloudflare Durable Objects for live game updates:

```javascript
export class GameRoom {
  constructor(state, env) {
    this.state = state;
    this.sessions = new Set();
  }
  
  async fetch(request) {
    // WebSocket connection for live updates
    const upgradeHeader = request.headers.get('Upgrade');
    if (upgradeHeader !== 'websocket') {
      return new Response('Expected websocket', { status: 400 });
    }
    
    const [client, server] = Object.values(new WebSocketPair());
    await this.handleSession(server);
    
    return new Response(null, {
      status: 101,
      webSocket: client,
    });
  }
  
  async handleSession(ws) {
    ws.accept();
    this.sessions.add(ws);
    
    ws.addEventListener('close', () => {
      this.sessions.delete(ws);
    });
  }
  
  broadcast(message) {
    for (const ws of this.sessions) {
      ws.send(JSON.stringify(message));
    }
  }
}
```

## Component Integration

Replace mock data in the React component:

```javascript
// Replace this:
const liveGames = [ /* mock data */ ];

// With this:
const [liveGames, setLiveGames] = useState([]);

useEffect(() => {
  fetch('/api/games/live')
    .then(r => r.json())
    .then(setLiveGames);
}, []);

// For live updates:
useEffect(() => {
  const ws = new WebSocket('wss://your-worker.workers.dev/game/123');
  ws.onmessage = (event) => {
    const update = JSON.parse(event.data);
    setLiveGames(games => 
      games.map(g => g.id === update.id ? update : g)
    );
  };
  return () => ws.close();
}, []);
```

## Mobile Optimization

Already built in:
- Touch-optimized tap targets (min 44x44px)
- Swipeable navigation
- Sticky headers for context while scrolling
- Optimized for one-handed use
- Fast scroll performance
- Offline-ready structure

## Next Steps

1. **Set up D1 database** with the schema above
2. **Create Worker endpoints** for API calls
3. **Build scrapers** for NCAA/conference data
4. **Set up cron triggers** for regular updates (every 30-60 seconds during games)
5. **Replace mock data** in component with API calls
6. **Deploy to Cloudflare Pages** for hosting

## Why This Beats ESPN

| Feature | ESPN | Blaze Sports Intel |
|---------|------|-------------------|
| Full box scores | ❌ No | ✅ Yes |
| Player stats | ❌ No | ✅ Yes |
| All 300+ teams | ❌ No | ✅ Yes |
| Conference parity | ❌ SEC-biased | ✅ Equal coverage |
| Mobile-first | ⚠️ Clunky | ✅ Optimized |
| Live updates | ✅ Yes | ✅ Yes |

Source: Your frustration with ESPN's college baseball coverage, 2025-10-15
