# Cloudflare Deployment Guide

## Project Structure

```
blaze-sports-intel/
├── src/
│   ├── components/
│   │   └── BlazeSportsIntelDashboard.jsx
│   ├── App.jsx
│   └── index.jsx
├── workers/
│   ├── api/
│   │   ├── games.js
│   │   ├── boxscore.js
│   │   └── standings.js
│   ├── scrapers/
│   │   ├── ncaa-scraper.js
│   │   ├── sec-scraper.js
│   │   └── schedule.js
│   └── live-updates/
│       └── game-room.js
├── schema.sql
├── wrangler.toml
└── package.json
```

## wrangler.toml Configuration

```toml
name = "blaze-sports-intel"
main = "workers/api/index.js"
compatibility_date = "2025-10-15"

# D1 Database
[[d1_databases]]
binding = "DB"
database_name = "blaze_sports"
database_id = "your-database-id-here"

# KV for caching
[[kv_namespaces]]
binding = "CACHE"
id = "your-kv-id-here"

# R2 for images/assets
[[r2_buckets]]
binding = "ASSETS"
bucket_name = "blaze-sports-assets"

# Durable Objects for live updates
[[durable_objects.bindings]]
name = "GAME_ROOMS"
class_name = "GameRoom"
script_name = "blaze-sports-intel"

[[migrations]]
tag = "v1"
new_classes = ["GameRoom"]

# Cron triggers for data updates
[triggers]
crons = [
  "*/1 * * * *",  # Every minute during game times
]

# Environment variables
[vars]
ENVIRONMENT = "production"

# Routes
[[routes]]
pattern = "blazesportsintel.com/api/*"
zone_name = "blazesportsintel.com"

# Pages project (frontend)
[pages_build_output]
directory = "dist"
```

## Setup Commands

### 1. Initialize Cloudflare Project

```bash
# Install Wrangler CLI
npm install -g wrangler

# Login to Cloudflare
wrangler login

# Create D1 database
wrangler d1 create blaze_sports

# Copy the database_id from output and add to wrangler.toml

# Create tables
wrangler d1 execute blaze_sports --file=schema.sql
```

### 2. Create KV Namespace

```bash
# Create KV for caching
wrangler kv:namespace create "CACHE"

# Copy the id from output and add to wrangler.toml
```

### 3. Create R2 Bucket

```bash
# Create R2 bucket for team logos/assets
wrangler r2 bucket create blaze-sports-assets
```

### 4. Deploy Workers

```bash
# Deploy API worker
wrangler deploy

# Deploy scraper worker
wrangler deploy workers/scrapers/ncaa-scraper.js --name ncaa-scraper

# Deploy live updates
wrangler deploy workers/live-updates/game-room.js --name game-rooms
```

### 5. Deploy Frontend to Pages

```bash
# Build React app
npm run build

# Deploy to Pages
wrangler pages deploy dist --project-name=blaze-sports-intel
```

## Worker Code Examples

### API Router (workers/api/index.js)

```javascript
import { Router } from 'itty-router';

const router = Router();

// CORS headers
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

// Live games endpoint
router.get('/api/games/live', async (request, env) => {
  const cacheKey = `games:live:${new Date().toISOString().split('T')[0]}`;
  
  // Check cache
  const cached = await env.CACHE.get(cacheKey);
  if (cached) {
    return new Response(cached, {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
  
  // Fetch from D1
  const games = await env.DB.prepare(`
    SELECT 
      g.id,
      g.home_score,
      g.away_score,
      g.status,
      g.inning,
      g.situation,
      g.venue,
      g.attendance,
      g.conference,
      ht.name as home_team_name,
      ht.abbr as home_team_abbr,
      at.name as away_team_name,
      at.abbr as away_team_abbr,
      hs.overall_wins as home_wins,
      hs.overall_losses as home_losses,
      hs.conf_wins as home_conf_wins,
      hs.conf_losses as home_conf_losses,
      hs.rank as home_rank,
      as.overall_wins as away_wins,
      as.overall_losses as away_losses,
      as.conf_wins as away_conf_wins,
      as.conf_losses as away_conf_losses,
      as.rank as away_rank
    FROM games g
    JOIN teams ht ON g.home_team_id = ht.id
    JOIN teams at ON g.away_team_id = at.id
    LEFT JOIN standings hs ON ht.id = hs.team_id
    LEFT JOIN standings as ON at.id = as.team_id
    WHERE g.status IN ('live', 'final', 'scheduled')
      AND DATE(g.game_date) >= DATE('now', '-1 day')
    ORDER BY 
      CASE 
        WHEN g.status = 'live' THEN 0
        WHEN g.status = 'final' THEN 1
        ELSE 2
      END,
      g.game_date DESC
    LIMIT 50
  `).all();
  
  const response = JSON.stringify(games.results);
  
  // Cache for 60 seconds
  await env.CACHE.put(cacheKey, response, { expirationTtl: 60 });
  
  return new Response(response, {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
  });
});

// Box score endpoint
router.get('/api/games/:id/boxscore', async (request, env) => {
  const { id } = request.params;
  const cacheKey = `boxscore:${id}`;
  
  const cached = await env.CACHE.get(cacheKey);
  if (cached) {
    return new Response(cached, {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
  
  // Get batting stats
  const batting = await env.DB.prepare(`
    SELECT 
      ps.*,
      t.abbr as team_abbr
    FROM player_stats ps
    JOIN teams t ON ps.team_id = t.id
    WHERE ps.game_id = ? AND ps.at_bats > 0
    ORDER BY ps.team_id, ps.at_bats DESC
  `).bind(id).all();
  
  // Get pitching stats
  const pitching = await env.DB.prepare(`
    SELECT 
      ps.*,
      t.abbr as team_abbr
    FROM player_stats ps
    JOIN teams t ON ps.team_id = t.id
    WHERE ps.game_id = ? AND ps.innings_pitched > 0
    ORDER BY ps.team_id, ps.innings_pitched DESC
  `).bind(id).all();
  
  const response = JSON.stringify({
    batting: batting.results,
    pitching: pitching.results
  });
  
  // Cache for 30 seconds during live games
  await env.CACHE.put(cacheKey, response, { expirationTtl: 30 });
  
  return new Response(response, {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
  });
});

// Standings endpoint
router.get('/api/standings/:conference', async (request, env) => {
  const { conference } = request.params;
  const cacheKey = `standings:${conference}`;
  
  const cached = await env.CACHE.get(cacheKey);
  if (cached) {
    return new Response(cached, {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
  
  const standings = await env.DB.prepare(`
    SELECT 
      s.rank,
      t.name as team,
      s.conf_wins || '-' || s.conf_losses as conf,
      s.overall_wins || '-' || s.overall_losses as overall,
      CASE 
        WHEN s.rank = 1 THEN '-'
        ELSE CAST(
          (SELECT (conf_wins * 1.0 / NULLIF(conf_wins + conf_losses, 0)) 
           FROM standings WHERE rank = 1 AND conference = s.conference) -
          (s.conf_wins * 1.0 / NULLIF(s.conf_wins + s.conf_losses, 0))
          AS TEXT
        )
      END as gb,
      s.streak
    FROM standings s
    JOIN teams t ON s.team_id = t.id
    WHERE s.conference = ?
    ORDER BY 
      (s.conf_wins * 1.0 / NULLIF(s.conf_wins + s.conf_losses, 0)) DESC,
      s.conf_wins DESC
  `).bind(conference).all();
  
  const response = JSON.stringify(standings.results);
  
  // Cache standings for 5 minutes
  await env.CACHE.put(cacheKey, response, { expirationTtl: 300 });
  
  return new Response(response, {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
  });
});

// Handle CORS preflight
router.options('*', () => {
  return new Response(null, { headers: corsHeaders });
});

// 404 handler
router.all('*', () => {
  return new Response('Not Found', { status: 404 });
});

export default {
  fetch: router.handle
};
```

### NCAA Scraper (workers/scrapers/ncaa-scraper.js)

```javascript
export default {
  async scheduled(event, env, ctx) {
    console.log('Starting NCAA scraper...');
    
    // Scrape NCAA stats page
    // Note: You'll need to reverse engineer their API or scrape HTML
    const response = await fetch(
      'https://stats.ncaa.org/game/index?sport_code=MBA&academic_year=2025'
    );
    
    const html = await response.text();
    
    // Parse games from HTML or JSON
    // This is where you'd use a library like cheerio or parse their data format
    const games = parseNcaaGames(html);
    
    // Update D1 database
    for (const game of games) {
      await env.DB.prepare(`
        INSERT OR REPLACE INTO games 
        (id, home_team_id, away_team_id, home_score, away_score, 
         status, inning, venue, game_date, conference)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        game.id,
        game.homeTeamId,
        game.awayTeamId,
        game.homeScore,
        game.awayScore,
        game.status,
        game.inning,
        game.venue,
        game.gameDate,
        game.conference
      ).run();
      
      // Update player stats if available
      if (game.playerStats) {
        for (const stat of game.playerStats) {
          await env.DB.prepare(`
            INSERT OR REPLACE INTO player_stats 
            (game_id, team_id, player_name, position, 
             at_bats, runs, hits, rbis, walks, strikeouts, batting_avg)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `).bind(
            game.id,
            stat.teamId,
            stat.playerName,
            stat.position,
            stat.ab,
            stat.r,
            stat.h,
            stat.rbi,
            stat.bb,
            stat.so,
            stat.avg
          ).run();
        }
      }
    }
    
    // Clear relevant caches
    await env.CACHE.delete(`games:live:${new Date().toISOString().split('T')[0]}`);
    
    console.log(`Updated ${games.length} games`);
  }
};

function parseNcaaGames(html) {
  // Implementation depends on NCAA's HTML structure
  // You'll need to inspect their page and extract data
  return [];
}
```

### Live Updates with Durable Objects (workers/live-updates/game-room.js)

```javascript
export class GameRoom {
  constructor(state, env) {
    this.state = state;
    this.sessions = new Set();
    this.gameId = null;
  }
  
  async fetch(request) {
    const url = new URL(request.url);
    this.gameId = url.pathname.split('/')[2];
    
    // WebSocket upgrade
    const upgradeHeader = request.headers.get('Upgrade');
    if (upgradeHeader !== 'websocket') {
      return new Response('Expected websocket', { status: 400 });
    }
    
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    
    await this.handleSession(server);
    
    return new Response(null, {
      status: 101,
      webSocket: client,
    });
  }
  
  async handleSession(ws) {
    ws.accept();
    this.sessions.add(ws);
    
    // Send initial game state
    const gameState = await this.getGameState();
    ws.send(JSON.stringify({ type: 'init', data: gameState }));
    
    ws.addEventListener('close', () => {
      this.sessions.delete(ws);
    });
  }
  
  async getGameState() {
    // Fetch from D1 via binding
    return {}; // Game state
  }
  
  // Called by scraper to broadcast updates
  async broadcastUpdate(update) {
    const message = JSON.stringify({ type: 'update', data: update });
    for (const ws of this.sessions) {
      try {
        ws.send(message);
      } catch (e) {
        ws.close();
        this.sessions.delete(ws);
      }
    }
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const gameId = url.pathname.split('/')[2];
    
    // Get Durable Object instance for this game
    const id = env.GAME_ROOMS.idFromName(gameId);
    const stub = env.GAME_ROOMS.get(id);
    
    return stub.fetch(request);
  }
};
```

## Environment Setup

### Local Development

```bash
# Install dependencies
npm install

# Run local dev server
npm run dev

# Test workers locally
wrangler dev
```

### Production Deployment

```bash
# Deploy everything
npm run deploy

# Or deploy individually
wrangler deploy                          # API worker
wrangler pages deploy dist              # Frontend
```

## Monitoring & Analytics

Add to your worker:

```javascript
// Track API usage
await env.ANALYTICS.writeDataPoint({
  blobs: [request.url, request.cf.country],
  doubles: [Date.now()],
  indexes: ['api-request']
});
```

## Cost Estimates

With 100k daily active users:
- **Workers**: ~$5/month (10M requests)
- **D1**: ~$1/month (storage + reads)
- **KV**: ~$0.50/month (reads)
- **R2**: ~$1/month (storage)
- **Pages**: Free (included)

**Total: ~$7.50/month** vs ESPN's inability to show box scores.

---

Source: Cloudflare documentation, 2025-10-15
Built for Austin Humphrey / Blaze Sports Intel
