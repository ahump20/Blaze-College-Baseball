import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Search, Bell, Menu, Star, TrendingUp, Calendar, Users, X, Filter } from 'lucide-react';

const BlazeSportsIntelDashboard = () => {
  const [selectedSport, setSelectedSport] = useState('college-baseball');
  const [selectedGame, setSelectedGame] = useState(null);
  const [activeTab, setActiveTab] = useState('scores');
  const [showMenu, setShowMenu] = useState(false);

  const sports = [
    { id: 'college-baseball', name: 'College Baseball', icon: '⚾', count: 47 },
    { id: 'track-field', name: 'Track & Field', icon: '🏃', count: 12 },
    { id: 'ncaa-soccer', name: 'NCAA Soccer', icon: '⚽', count: 8 },
    { id: 'softball', name: 'Softball', icon: '🥎', count: 23 },
    { id: 'mlb', name: 'MLB', icon: '⚾', count: 15 },
    { id: 'nfl', name: 'NFL', icon: '🏈', count: 10 },
  ];

  const liveGames = [
    {
      id: 1,
      homeTeam: { name: 'Texas', abbr: 'TEX', rank: 8, record: '32-12, 15-7 SEC' },
      awayTeam: { name: 'LSU', abbr: 'LSU', rank: 4, record: '35-9, 17-5 SEC' },
      homeScore: 4,
      awayScore: 3,
      status: 'Bot 7th',
      conference: 'SEC',
      venue: 'UFCU Disch-Falk Field',
      attendance: '7,373',
      situation: 'Runners on 1st & 2nd, 1 out',
      probables: {
        away: { name: 'P. Skenes', era: '1.69', record: '9-1' },
        home: { name: 'L. Gordon', era: '2.84', record: '7-2' }
      }
    },
    {
      id: 2,
      homeTeam: { name: 'Vanderbilt', abbr: 'VAN', rank: 12, record: '28-15, 12-10 SEC' },
      awayTeam: { name: 'Tennessee', abbr: 'TEN', rank: 3, record: '38-6, 18-4 SEC' },
      homeScore: 2,
      awayScore: 5,
      status: 'Top 8th',
      conference: 'SEC',
      venue: 'Hawkins Field',
      attendance: '3,626',
      situation: 'Bases empty, 2 outs',
    },
    {
      id: 3,
      homeTeam: { name: 'Oregon State', abbr: 'ORE', rank: null, record: '25-18, 11-9 Pac-12' },
      awayTeam: { name: 'Stanford', abbr: 'STA', rank: 18, record: '29-14, 13-8 Pac-12' },
      homeScore: 1,
      awayScore: 1,
      status: 'Mid 5th',
      conference: 'Pac-12',
      venue: 'Goss Stadium',
      attendance: '3,248',
      situation: 'Bases loaded, 0 outs',
    },
    {
      id: 4,
      homeTeam: { name: 'Coastal Carolina', abbr: 'CCU', rank: 22, record: '31-13, 16-6 Sun Belt' },
      awayTeam: { name: 'Troy', abbr: 'TRO', rank: null, record: '23-21, 10-12 Sun Belt' },
      homeScore: 8,
      awayScore: 4,
      status: 'Final',
      conference: 'Sun Belt',
      venue: 'Springs Brooks Stadium',
      attendance: '2,891',
    }
  ];

  const boxScoreData = {
    away: {
      team: 'LSU',
      abbr: 'LSU',
      lineScore: [0, 1, 0, 0, 2, 0, 0, 0, 0],
      runs: 3,
      hits: 7,
      errors: 1,
      batting: [
        { player: 'J. Thompson', pos: 'CF', ab: 3, r: 1, h: 2, rbi: 0, bb: 1, so: 0, avg: '.342' },
        { player: 'M. Dugas', pos: 'C', ab: 4, r: 0, h: 1, rbi: 1, bb: 0, so: 1, avg: '.318' },
        { player: 'T. Crews', pos: 'SS', ab: 4, r: 1, h: 1, rbi: 0, bb: 0, so: 2, avg: '.295' },
        { player: 'J. Pearson', pos: '1B', ab: 3, r: 0, h: 0, rbi: 0, bb: 1, so: 1, avg: '.287' },
        { player: 'B. Doughty', pos: 'DH', ab: 4, r: 1, h: 2, rbi: 2, bb: 0, so: 0, avg: '.331' },
        { player: 'G. Nootbaar', pos: 'RF', ab: 4, r: 0, h: 1, rbi: 0, bb: 0, so: 1, avg: '.276' },
        { player: 'C. Breaux', pos: '3B', ab: 3, r: 0, h: 0, rbi: 0, bb: 0, so: 2, avg: '.258' },
        { player: 'J. Duplantis', pos: 'LF', ab: 3, r: 0, h: 0, rbi: 0, bb: 0, so: 1, avg: '.312' },
        { player: 'H. Fontenot', pos: '2B', ab: 3, r: 0, h: 0, rbi: 0, bb: 0, so: 2, avg: '.241' },
      ],
      pitching: [
        { player: 'P. Skenes', ip: '6.0', h: 4, r: 3, er: 2, bb: 2, so: 11, era: '1.69', pitches: 98 },
        { player: 'R. Davis', ip: '0.2', h: 1, r: 1, er: 1, bb: 1, so: 1, era: '3.24', pitches: 22 },
      ],
    },
    home: {
      team: 'Texas',
      abbr: 'TEX',
      lineScore: [1, 0, 0, 2, 0, 0, 1, 0, 0],
      runs: 4,
      hits: 8,
      errors: 0,
      batting: [
        { player: 'D. Kennedy', pos: 'SS', ab: 4, r: 1, h: 2, rbi: 1, bb: 0, so: 0, avg: '.327' },
        { player: 'I. Melendez', pos: 'C', ab: 3, r: 1, h: 1, rbi: 0, bb: 1, so: 1, avg: '.346' },
        { player: 'M. Shaw', pos: '1B', ab: 4, r: 0, h: 1, rbi: 1, bb: 0, so: 2, avg: '.298' },
        { player: 'Z. Zubia', pos: 'DH', ab: 3, r: 1, h: 2, rbi: 2, bb: 1, so: 0, avg: '.315' },
        { player: 'E. Kennedy', pos: 'RF', ab: 4, r: 0, h: 1, rbi: 0, bb: 0, so: 1, avg: '.289' },
        { player: 'P. Mathis', pos: 'CF', ab: 3, r: 1, h: 1, rbi: 0, bb: 1, so: 0, avg: '.267' },
        { player: 'C. Messinger', pos: 'LF', ab: 4, r: 0, h: 0, rbi: 0, bb: 0, so: 2, avg: '.254' },
        { player: 'S. Stehly', pos: '2B', ab: 3, r: 0, h: 0, rbi: 0, bb: 0, so: 1, avg: '.276' },
        { player: 'D. Luthy', pos: '3B', ab: 3, r: 0, h: 0, rbi: 0, bb: 0, so: 2, avg: '.241' },
      ],
      pitching: [
        { player: 'L. Gordon', ip: '5.1', h: 5, r: 3, er: 3, bb: 1, so: 7, era: '2.84', pitches: 87 },
        { player: 'A. Nixon', ip: '1.2', h: 2, r: 0, er: 0, bb: 1, so: 3, era: '2.15', pitches: 31 },
      ],
    }
  };

  const standings = [
    { rank: 1, team: 'Arkansas', conf: '19-3', overall: '39-7', gb: '-', streak: 'W7' },
    { rank: 2, team: 'Tennessee', conf: '18-4', overall: '38-6', gb: '1.0', streak: 'W5' },
    { rank: 3, team: 'LSU', conf: '17-5', overall: '35-9', gb: '2.0', streak: 'L1' },
    { rank: 4, team: 'Florida', conf: '16-6', overall: '33-11', gb: '3.0', streak: 'W3' },
    { rank: 5, team: 'Texas', conf: '15-7', overall: '32-12', gb: '4.0', streak: 'W1' },
    { rank: 6, team: 'Mississippi State', conf: '14-8', overall: '30-14', gb: '5.0', streak: 'L2' },
    { rank: 7, team: 'Ole Miss', conf: '13-9', overall: '29-15', gb: '6.0', streak: 'W2' },
    { rank: 8, team: 'Vanderbilt', conf: '12-10', overall: '28-15', gb: '7.0', streak: 'L1' },
  ];

  const upcomingGames = [
    { date: 'Tomorrow', time: '7:00 PM CT', home: 'Texas', away: 'LSU', tv: 'SECN+' },
    { date: 'Tomorrow', time: '6:30 PM CT', home: 'Vanderbilt', away: 'Tennessee', tv: 'SEC Network' },
    { date: 'Friday', time: '7:00 PM CT', home: 'Oregon State', away: 'UCLA', tv: 'Pac-12 Network' },
  ];

  const GameCard = ({ game }) => {
    const isLive = !game.status.includes('Final');
    const isSelected = selectedGame?.id === game.id;

    return (
      <div 
        onClick={() => setSelectedGame(game)}
        className={`bg-gray-800 rounded-lg p-4 mb-3 border-2 transition-all ${
          isSelected ? 'border-orange-500' : 'border-gray-700'
        } active:scale-98`}
      >
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            {isLive && (
              <div className="flex items-center">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse mr-2"></div>
                <span className="text-red-500 text-xs font-bold">LIVE</span>
              </div>
            )}
            <span className="text-gray-400 text-xs">{game.conference}</span>
          </div>
          <span className="text-gray-400 text-xs">{game.venue}</span>
        </div>

        {/* Away Team */}
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-3 flex-1">
            {game.awayTeam.rank && (
              <span className="text-yellow-500 font-bold text-sm">#{game.awayTeam.rank}</span>
            )}
            <div>
              <div className="font-bold text-white">{game.awayTeam.name}</div>
              <div className="text-xs text-gray-400">{game.awayTeam.record}</div>
            </div>
          </div>
          <div className="text-2xl font-bold text-white">{game.awayScore}</div>
        </div>

        {/* Home Team */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-3 flex-1">
            {game.homeTeam.rank && (
              <span className="text-yellow-500 font-bold text-sm">#{game.homeTeam.rank}</span>
            )}
            <div>
              <div className="font-bold text-white">{game.homeTeam.name}</div>
              <div className="text-xs text-gray-400">{game.homeTeam.record}</div>
            </div>
          </div>
          <div className="text-2xl font-bold text-white">{game.homeScore}</div>
        </div>

        {/* Game Status */}
        <div className="flex items-center justify-between pt-2 border-t border-gray-700">
          <span className="text-orange-500 font-semibold text-sm">{game.status}</span>
          {game.situation && isLive && (
            <span className="text-gray-400 text-xs">{game.situation}</span>
          )}
          {game.attendance && (
            <span className="text-gray-400 text-xs">Att: {game.attendance}</span>
          )}
        </div>

        {/* Tap to view full box score hint */}
        <div className="mt-2 text-center text-orange-400 text-xs">
          Tap for full box score →
        </div>
      </div>
    );
  };

  const BoxScore = () => {
    if (!selectedGame) return null;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-95 z-50 overflow-y-auto">
        <div className="min-h-screen p-4">
          {/* Header */}
          <div className="flex items-center justify-between mb-4 sticky top-0 bg-black py-2">
            <h2 className="text-xl font-bold text-white">Box Score</h2>
            <button 
              onClick={() => setSelectedGame(null)}
              className="text-white p-2"
            >
              <X size={24} />
            </button>
          </div>

          {/* Game Summary */}
          <div className="bg-gray-800 rounded-lg p-4 mb-4">
            <div className="text-center mb-2">
              <span className="text-gray-400 text-sm">{selectedGame.conference}</span>
              <span className="text-gray-400 text-sm mx-2">•</span>
              <span className="text-gray-400 text-sm">{selectedGame.venue}</span>
            </div>
            <div className="flex justify-around items-center">
              <div className="text-center">
                <div className="font-bold text-lg text-white">{selectedGame.awayTeam.name}</div>
                <div className="text-3xl font-bold text-white">{selectedGame.awayScore}</div>
              </div>
              <div className="text-gray-500 text-2xl">-</div>
              <div className="text-center">
                <div className="font-bold text-lg text-white">{selectedGame.homeTeam.name}</div>
                <div className="text-3xl font-bold text-white">{selectedGame.homeScore}</div>
              </div>
            </div>
            <div className="text-center mt-2">
              <span className="text-orange-500 font-semibold">{selectedGame.status}</span>
            </div>
          </div>

          {/* Line Score */}
          <div className="bg-gray-800 rounded-lg p-4 mb-4 overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-gray-400">
                  <th className="text-left py-2">Team</th>
                  {[1,2,3,4,5,6,7,8,9].map(i => (
                    <th key={i} className="text-center px-1">{i}</th>
                  ))}
                  <th className="text-center px-2">R</th>
                  <th className="text-center px-2">H</th>
                  <th className="text-center px-2">E</th>
                </tr>
              </thead>
              <tbody className="text-white">
                <tr className="border-t border-gray-700">
                  <td className="py-2 font-semibold">{boxScoreData.away.abbr}</td>
                  {boxScoreData.away.lineScore.map((score, i) => (
                    <td key={i} className="text-center px-1">{score}</td>
                  ))}
                  <td className="text-center px-2 font-bold">{boxScoreData.away.runs}</td>
                  <td className="text-center px-2">{boxScoreData.away.hits}</td>
                  <td className="text-center px-2">{boxScoreData.away.errors}</td>
                </tr>
                <tr className="border-t border-gray-700">
                  <td className="py-2 font-semibold">{boxScoreData.home.abbr}</td>
                  {boxScoreData.home.lineScore.map((score, i) => (
                    <td key={i} className="text-center px-1">{score}</td>
                  ))}
                  <td className="text-center px-2 font-bold">{boxScoreData.home.runs}</td>
                  <td className="text-center px-2">{boxScoreData.home.hits}</td>
                  <td className="text-center px-2">{boxScoreData.home.errors}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Away Team Batting */}
          <div className="bg-gray-800 rounded-lg p-4 mb-4">
            <h3 className="font-bold text-white mb-3">{boxScoreData.away.team} Batting</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-gray-400 border-b border-gray-700">
                    <th className="text-left py-2 pr-2">Player</th>
                    <th className="text-center px-1">AB</th>
                    <th className="text-center px-1">R</th>
                    <th className="text-center px-1">H</th>
                    <th className="text-center px-1">RBI</th>
                    <th className="text-center px-1">BB</th>
                    <th className="text-center px-1">SO</th>
                    <th className="text-center px-1">AVG</th>
                  </tr>
                </thead>
                <tbody className="text-white">
                  {boxScoreData.away.batting.map((player, i) => (
                    <tr key={i} className="border-b border-gray-700">
                      <td className="py-2 pr-2">
                        <div className="font-semibold">{player.player}</div>
                        <div className="text-gray-400">{player.pos}</div>
                      </td>
                      <td className="text-center px-1">{player.ab}</td>
                      <td className="text-center px-1">{player.r}</td>
                      <td className="text-center px-1">{player.h}</td>
                      <td className="text-center px-1">{player.rbi}</td>
                      <td className="text-center px-1">{player.bb}</td>
                      <td className="text-center px-1">{player.so}</td>
                      <td className="text-center px-1">{player.avg}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Away Team Pitching */}
          <div className="bg-gray-800 rounded-lg p-4 mb-4">
            <h3 className="font-bold text-white mb-3">{boxScoreData.away.team} Pitching</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-gray-400 border-b border-gray-700">
                    <th className="text-left py-2 pr-2">Player</th>
                    <th className="text-center px-1">IP</th>
                    <th className="text-center px-1">H</th>
                    <th className="text-center px-1">R</th>
                    <th className="text-center px-1">ER</th>
                    <th className="text-center px-1">BB</th>
                    <th className="text-center px-1">SO</th>
                    <th className="text-center px-1">ERA</th>
                    <th className="text-center px-1">P</th>
                  </tr>
                </thead>
                <tbody className="text-white">
                  {boxScoreData.away.pitching.map((player, i) => (
                    <tr key={i} className="border-b border-gray-700">
                      <td className="py-2 pr-2 font-semibold">{player.player}</td>
                      <td className="text-center px-1">{player.ip}</td>
                      <td className="text-center px-1">{player.h}</td>
                      <td className="text-center px-1">{player.r}</td>
                      <td className="text-center px-1">{player.er}</td>
                      <td className="text-center px-1">{player.bb}</td>
                      <td className="text-center px-1">{player.so}</td>
                      <td className="text-center px-1">{player.era}</td>
                      <td className="text-center px-1">{player.pitches}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Home Team Batting */}
          <div className="bg-gray-800 rounded-lg p-4 mb-4">
            <h3 className="font-bold text-white mb-3">{boxScoreData.home.team} Batting</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-gray-400 border-b border-gray-700">
                    <th className="text-left py-2 pr-2">Player</th>
                    <th className="text-center px-1">AB</th>
                    <th className="text-center px-1">R</th>
                    <th className="text-center px-1">H</th>
                    <th className="text-center px-1">RBI</th>
                    <th className="text-center px-1">BB</th>
                    <th className="text-center px-1">SO</th>
                    <th className="text-center px-1">AVG</th>
                  </tr>
                </thead>
                <tbody className="text-white">
                  {boxScoreData.home.batting.map((player, i) => (
                    <tr key={i} className="border-b border-gray-700">
                      <td className="py-2 pr-2">
                        <div className="font-semibold">{player.player}</div>
                        <div className="text-gray-400">{player.pos}</div>
                      </td>
                      <td className="text-center px-1">{player.ab}</td>
                      <td className="text-center px-1">{player.r}</td>
                      <td className="text-center px-1">{player.h}</td>
                      <td className="text-center px-1">{player.rbi}</td>
                      <td className="text-center px-1">{player.bb}</td>
                      <td className="text-center px-1">{player.so}</td>
                      <td className="text-center px-1">{player.avg}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Home Team Pitching */}
          <div className="bg-gray-800 rounded-lg p-4 mb-4">
            <h3 className="font-bold text-white mb-3">{boxScoreData.home.team} Pitching</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-gray-400 border-b border-gray-700">
                    <th className="text-left py-2 pr-2">Player</th>
                    <th className="text-center px-1">IP</th>
                    <th className="text-center px-1">H</th>
                    <th className="text-center px-1">R</th>
                    <th className="text-center px-1">ER</th>
                    <th className="text-center px-1">BB</th>
                    <th className="text-center px-1">SO</th>
                    <th className="text-center px-1">ERA</th>
                    <th className="text-center px-1">P</th>
                  </tr>
                </thead>
                <tbody className="text-white">
                  {boxScoreData.home.pitching.map((player, i) => (
                    <tr key={i} className="border-b border-gray-700">
                      <td className="py-2 pr-2 font-semibold">{player.player}</td>
                      <td className="text-center px-1">{player.ip}</td>
                      <td className="text-center px-1">{player.h}</td>
                      <td className="text-center px-1">{player.r}</td>
                      <td className="text-center px-1">{player.er}</td>
                      <td className="text-center px-1">{player.bb}</td>
                      <td className="text-center px-1">{player.so}</td>
                      <td className="text-center px-1">{player.era}</td>
                      <td className="text-center px-1">{player.pitches}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-600 to-orange-500 p-4 sticky top-0 z-40">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <button onClick={() => setShowMenu(!showMenu)}>
              <Menu size={24} />
            </button>
            <div>
              <h1 className="text-xl font-bold">Blaze Sports Intel</h1>
              <p className="text-xs text-orange-50">Every team. Every conference. Every game.</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button className="p-2"><Search size={20} /></button>
            <button className="p-2 relative">
              <Bell size={20} />
              <div className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></div>
            </button>
          </div>
        </div>
      </div>

      {/* Sport Selector */}
      <div className="bg-gray-900 p-3 overflow-x-auto scrollbar-hide sticky top-16 z-30 border-b border-gray-800">
        <div className="flex space-x-2 min-w-max">
          {sports.map(sport => (
            <button
              key={sport.id}
              onClick={() => setSelectedSport(sport.id)}
              className={`px-4 py-2 rounded-full text-sm font-semibold transition-all whitespace-nowrap ${
                selectedSport === sport.id
                  ? 'bg-orange-500 text-white'
                  : 'bg-gray-800 text-gray-300'
              }`}
            >
              <span className="mr-2">{sport.icon}</span>
              {sport.name}
              <span className="ml-2 text-xs opacity-75">({sport.count})</span>
            </button>
          ))}
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-gray-900 p-3 flex space-x-4 border-b border-gray-800 sticky top-32 z-30">
        {['scores', 'standings', 'schedule'].map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-sm font-semibold transition-all ${
              activeTab === tab
                ? 'text-orange-500 border-b-2 border-orange-500'
                : 'text-gray-400'
            }`}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="p-4">
        {/* Hero Message */}
        <div className="bg-gradient-to-r from-orange-600 to-orange-500 rounded-lg p-6 mb-6">
          <h2 className="text-2xl font-bold mb-2">Full College Baseball Coverage</h2>
          <p className="text-orange-50 mb-3">
            Complete box scores, player stats, and standings for all 300+ D1 teams. 
            Not just SEC highlight clips.
          </p>
          <div className="mt-3 flex flex-wrap gap-3 text-xs text-orange-50">
            <div className="flex items-center">
              <span className="mr-1">✓</span> All 300+ D1 teams
            </div>
            <div className="flex items-center">
              <span className="mr-1">✓</span> Every conference
            </div>
            <div className="flex items-center">
              <span className="mr-1">✓</span> Real-time updates
            </div>
            <div className="flex items-center">
              <span className="mr-1">✓</span> Complete stats
            </div>
          </div>
        </div>

        {activeTab === 'scores' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold">Live & Recent Games</h3>
              <button className="text-orange-500 text-sm flex items-center">
                <Filter size={16} className="mr-1" />
                Filter
              </button>
            </div>
            {liveGames.map(game => (
              <GameCard key={game.id} game={game} />
            ))}
          </div>
        )}

        {activeTab === 'standings' && (
          <div>
            <div className="bg-gray-800 rounded-lg p-4 mb-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold">SEC Standings</h3>
                <button className="text-orange-500 text-sm">View All Conferences</button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-gray-400 border-b border-gray-700">
                      <th className="text-left py-2 pr-4">#</th>
                      <th className="text-left py-2 pr-4">Team</th>
                      <th className="text-center px-2">Conf</th>
                      <th className="text-center px-2">Overall</th>
                      <th className="text-center px-2">GB</th>
                      <th className="text-center px-2">Strk</th>
                    </tr>
                  </thead>
                  <tbody className="text-white">
                    {standings.map((team, i) => (
                      <tr key={i} className="border-b border-gray-700 hover:bg-gray-700">
                        <td className="py-3 pr-4">{team.rank}</td>
                        <td className="py-3 pr-4 font-semibold">{team.team}</td>
                        <td className="text-center px-2">{team.conf}</td>
                        <td className="text-center px-2">{team.overall}</td>
                        <td className="text-center px-2">{team.gb}</td>
                        <td className="text-center px-2">
                          <span className={team.streak.startsWith('W') ? 'text-green-500' : 'text-red-500'}>
                            {team.streak}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'schedule' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold">Upcoming Games</h3>
              <button className="text-orange-500 text-sm flex items-center">
                <Calendar size={16} className="mr-1" />
                Full Schedule
              </button>
            </div>
            {upcomingGames.map((game, i) => (
              <div key={i} className="bg-gray-800 rounded-lg p-4 mb-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-400 text-xs">{game.date}</span>
                  <span className="text-orange-500 text-xs font-semibold">{game.tv}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-bold text-white">{game.away}</div>
                    <div className="text-gray-400 text-sm">at</div>
                    <div className="font-bold text-white">{game.home}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-semibold text-white">{game.time}</div>
                    <button className="mt-2 px-3 py-1 bg-orange-500 text-white text-xs rounded-full">
                      Set Reminder
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Box Score Modal */}
      {selectedGame && <BoxScore />}

      {/* Floating Action Button */}
      <button className="fixed bottom-6 right-6 bg-orange-500 text-white p-4 rounded-full shadow-lg z-50">
        <TrendingUp size={24} />
      </button>

      <style jsx>{`
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .active\:scale-98:active {
          transform: scale(0.98);
        }
      `}</style>
    </div>
  );
};

export default BlazeSportsIntelDashboard;
